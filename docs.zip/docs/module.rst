База данных (db.py)
====================

.. automodule:: db
   :members:
   :undoc-members:
   :show-inheritance:

Сам бот (main.py)
====================

.. automodule:: main
   :members:
   :undoc-members:
   :show-inheritance:
